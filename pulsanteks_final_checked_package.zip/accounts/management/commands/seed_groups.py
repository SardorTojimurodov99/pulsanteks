from django.core.management.base import BaseCommand
from django.contrib.auth.models import Group


GROUPS = [
    "RANG_TAYYORLOVCHI",
    "QUYUVCHI",
    "APPARATCHI",
    "PALIROFKACHI",
    "SARTIROVKACHI",
    "OMBORCHI",
    "JONATUVCHI",
    "MASTER",
]


class Command(BaseCommand):
    help = "Worker grouplarni yaratadi"

    def handle(self, *args, **options):
        for name in GROUPS:
            Group.objects.get_or_create(name=name)

        self.stdout.write(self.style.SUCCESS("Grouplar yaratildi."))